/**
 * New node file
 */

var HtmlScreenshotReporter = require('protractor-jasmine2-html-reporter');

var today = new Date(),
    timeStamp = today.getMonth() + 1 + '-' + today.getDate() + '-' + today.getFullYear() + '-' + today.getHours() + 'h-' + today.getMinutes() + 'm';

var reporter = new HtmlScreenshotReporter({
    savePath: '../Test Report/Result'+timeStamp+'/',
    screenshotsFolder: 'images'
});

exports.config = {
    directconnect: true,

    //seleniumAddress: 'http://localhost:4444/wd/hub',,

    // Capabilities to be passed to the webdriver instance.
    capabilities: {
        'browserName': 'chrome'
    },

    // Spec patterns are relative to the current working directly when
    // protractor is called.

    framework: 'jasmine2',
     //specs: ['../Spec/test_spec.js'],
	 //specs: ['../Spec/test_spec_portfolioManag.js'],
	 specs: ['../Spec/test_spec_scenarioManag.js'],
           /* suites: {
			smoke: ['../smoke/test_spec.js'],
			regression: ['../regression/test.spec.js'],			
			//functional: ['../functional/test_spec.js'],
			//all: ['../!*!/!*.spec.js'],
			//selected: ['./functional/addcustomer.spec.js','./regression/openaccount.spec.js'],		
			
	},*/
	           //Allure report code
	/*var AllureReporter = require('jasmine-allure-reporter');
        jasmine.getEnv().addReporter(new AllureReporter({
			allureReport:{
				resultsDir: 'allure-results'
			}
        
}));
    jasmine.getEnv().afterEach(function(done){
      browser.takeScreenshot().then(function (png) {
        allure.createAttachment('Screenshot', function () {
          return new Buffer(png, 'base64')
        }, 'image/png')();
        done();
      })
    });
		
    },*/
    onPrepare: function() {
		//browser.driver.manage().window().maximize();
        jasmine.getEnv().addReporter(reporter);
    },

    // Options to be passed to Jasmine-node.
    jasmineNodeOpts: {
        showColors: true, 
  //defaultTimeoutInterval: 200000		
		getPageTimeout: 8000000,
     allScriptsTimeout: 8000000,
    },
};