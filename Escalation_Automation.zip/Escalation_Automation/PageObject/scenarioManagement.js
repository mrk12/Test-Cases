/**
 * login page
 */

require('../PageObject/scenarioManagement.js');
var SelectWrapper = require('./select-wrapper.js');

var scenarioMng = function() {
	
    	this.scenarioManagments = function(){
		element(By.css("#navitemlist > li:nth-child(5) > a > span")).click();
		};
		this.defineScenarioTab = function(){
		element(by.xpath("//section[@role='region']//px-tab[@class='iron-selected']/div[text()='Define Scenario']")).click();
		};
		this.defineScenarioTagDropdown = function(Value){
		new SelectWrapper(by.model("scenario.tag")).selectByValue(Value);
		};
		this.defineScenarioSearchButton = function(){
		element(By.css("input[value='Search Scenario']")).click();
		};
		this.defineScenarioAddButton = function(){
		element(By.css("i[class='fa fa-plus']")).click();
		};
		this.defineScenarioAddTagName = function(Value){
		new SelectWrapper(by.css("select[id^='drpScenarioTag']")).selectByValue(Value);
		};
		this.defineScenarioAddScenarioName = function(Value){
		element(by.css("input[id^='txtScenarioName']")).sendKeys(Value);
		};
		this.defineScenarioAddScenarioDesc = function(Value){
		element(by.css("input[id^='txtScenarioDesc']")).sendKeys(Value);
		};
		this.defineScenarioSaveButton = function(){
		element(By.css("#save")).click();
		};
  }; 
      
  module.exports= new scenarioMng();
  
  
  