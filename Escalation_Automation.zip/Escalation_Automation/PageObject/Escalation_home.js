/**
 * login page
 */

require('../PageObject/Escalation_home.js');
var SelectWrapper = require('./select-wrapper.js');

var Home_login = function() {
	
    this.sso_id=function(value){
		element(By.model("userId")).sendKeys(value);		
		};
		this.submit_button=function(){
			element(By.buttonText("Submit")).click();
            //browser.driver.sleep(5000);			
			};		
		this.role=function(value){
			new SelectWrapper(by.model("selectedRole")).selectByValue(value);
			};	
			
			this.enter_button=function(){
			element(By.buttonText("Enter")).click();            		
			};
			this.roleselection=function(){
			element(By.xpath("//*[@id='headertext'][text()='Role Selection']"));
            //browser.driver.sleep(5000);			
			};
  };   
      
  module.exports= new Home_login();