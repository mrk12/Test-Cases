/**
 * login page
 */

require('../PageObject/User_Management.js');
var SelectWrapper = require('./select-wrapper.js');

var User_Mang = function() {
	
    this.user_managm=function(){
		element(By.xpath("//ul[@id='navitemlist']//li/a/span[text()='User Management']")).click();		
				};
		this.Search_User=function(value){
		element(By.xpath("//div[@id='scrollBodyTableContainer']/div[2]/span[1]/input")).sendKeys(value);	
		};
		this.Edit_User=function(){
		element(By.xpath("//px-data-table-cell//a[@id='editTooltip']")).click();		
		};
		this.SelectUser_Role=function(){
		element(By.xpath("//*[@id='myModal']/section/div[2]/div[4]/input")).click();		
		};
		this.EditUser_SaveButton=function(){
		element(By.xpath("//px-modal[@id='modalEditRoles']//div[@class='modal__buttons flex flex--right style-scope px-modal']//button[text()='Save']")).click();		
		};
		this.Delete_User=function(){
		element(By.xpath("//*[@id='deleteTooltip']")).click();		
		};		
		this.Yes_Button=function(){
		element(By.xpath("//px-modal[@id='modalcnfrm']//div[@class='flex style-scope px-modal']/button[@id='Yes']")).click();		
		};	
		this.Adduser_Ssoid=function(value){
		element(By.xpath("//input[@id='sso']")).sendKeys(value);		
		};
		this.lookupSSO_button=function(){
			element(By.buttonText("Look Up SSO")).click();
			};
		this.Select_Role=function(){
			element(By.xpath("//*[@id='addUser']/fieldset/div[2]/span[2]/input")).click();
			};
		this.Adduser_Button=function(){
			element(By.buttonText("AddUser")).click();
			};
			
        // Model Mapping scripts
		//Model Mapping Add user
		this.modelMappingTab=function(){
			element(By.xpath("//div[@id='tabtitle'][text()='Model Mapping']")).click();
			};
		
		this.modelidSearchInput=function(value){
		element(By.model("modelID")).sendKeys(value);		
		};
		this.modelidSearchButton=function(){
		element(By.css("[value='Search']")).click();		
		};
        this.modelMappingAddButton=function(){
		element(By.xpath("//div[@id='myUserDiv']//span[@class='menuActions']/i[@id='add']")).click();		
		};
		this.modelidAddInput=function(value){
		element(By.xpath("//div[@class='tr rows striped style-scope aha-table']//input[@id='txtValue1']")).sendKeys(value);		
		};
		this.selectUsername=function(value){
			new SelectWrapper(by.xpath("//div[@class='scroll-body style-scope aha-table']//select[@id='drpUser1']")).selectByValue(value);
			};
		this.selectUserRole=function(value){
			new SelectWrapper(by.xpath("//div[@class='scroll-body style-scope aha-table']//select[@id='drpRole1']")).selectByValue(value);
			};
        this.saveButton=function(){
			element(by.id("save")).click();
			};        		
        	//Model Mapping edit user			
		this.modelMappingFilter=function(value){
		element(By.xpath("//div[@id='scrollBodyTableContainer']/div[2]/span[4]/input[@placeholder='Filter']")).sendKeys(value);        	
		};	
        this.modelMappingEditUser=function(){
		element(By.xpath("//div[@class='tr rows striped style-scope aha-table']//a[@id='editModelMapUserTooltip']")).click();		
		};
		this.ModelMappingSearchUser=function(){
		element(By.xpath("//div[@class='tr rows striped style-scope aha-table']//a[@id='editModelMapUserTooltip']")).getText(); 		
		};
		this.selectRolename=function(value){
			new SelectWrapper(by.model("editRole.key")).selectByText(value);
			};
		this.selectEditUsername=function(value){
			new SelectWrapper(by.model("editUser.key")).selectByText(value);
			};
         this.editUserSaveButton=function(){
		element(By.xpath("//*[@id='Save']")).click();		
		};
		//Model Mapping Delete user
		this.modelMappingFilterClear=function(){
		element(By.xpath("//div[@id='scrollBodyTableContainer']/div[2]/span[4]/input")).clear();			
		};
		this.deleteUserButton=function(){
		element(By.xpath("//aha-html-echo[@class='style-scope px-data-table-cell']/img[@id='deleteTooltip']")).click();		
		};	
  };  
      
  module.exports= new User_Mang();
  
  
  