/**
 * login page
 */

require('../PageObject/portfolioManagement.js');
var SelectWrapper = require('./select-wrapper.js');

var Portfolio_Mang = function() {
	
    	this.portfolioManagmentTab = function(){
		element(By.css("#navitemlist > li:nth-child(4) > a > span")).click();		
		};
		this.portfolioModelid=function(value){
		//element(By.css("input[placeholder='Model ID']")).sendKeys(value);
     element(By.model("editModel.modelId")).sendKeys(value);		
		};				
		this.portfolioSearchButton = function(){
		element(By.css("input[type='submit']")).click();
		};
		// Add portfolio record - Portfolio Management
		this.portfolioSaveButton = function(){
		element(By.css("img[id='save']")).click();
		};
		
		this.portfolioAddButton = function(){
		element(By.css("i[id='add']")).click();
		};
		this.portfolioAddModelid = function(Value){
		element(By.css("input[id^='modelIdValue']")).sendKeys(Value);
		};	
		this.portfolioAddContractNumber = function(Value){
		element(by.css("input[id^='contractNumValue']")).sendKeys(Value);
		};
		
        this.portfolioAddCustomerName = function(Value){
		element(by.css("input[id^='custNameValue']")).sendKeys(Value);
		};
		this.portfolioAddStartDate = function(Value){
		element(by.css("input[id^='startDateValue']")).sendKeys(Value);
		};
		this.portfolioAddEndDate = function(Value){
		element(by.css("input[id^='endDateValue']")).sendKeys(Value);
		};
		this.portfolioAddMrQuarter = function(Value){
		new SelectWrapper(by.css("select[id^='drpQuarters']")).selectByText(value);
		};
		this.portfolioAddRegion = function(Value){
		new SelectWrapper(by.css("select[id^='drpRegions']")).selectByValue(Value);
		};
		this.portfolioAddLastLockedMR = function(Value){
		new SelectWrapper(by.css("select[id^='drpLastLockedMRVer']")).selectByValue(Value);
		};
		this.portfolioAddOptions = function(Value){
		new SelectWrapper(by.css("select[id^='drpOptions']")).selectByValue(Value);
		};
		// Edit portfolio record - Portfolio Management
		this.portfolioEditModel = function(){
		element(by.css("#editModelTooltip")).click();
		};
		this.portfolioEditRegionModel = function(Value){
		new SelectWrapper(by.model("editRegions.editedRegion")).selectByValue(Value);
		};
		this.portfolioEditComments = function(Value){
		element(by.model("editModelTable.comments")).sendKeys(Value);
		};
		this.portfolioEditSaveButton = function(){
		element(by.xpath("//section[@class='modal__content u-p+ style-scope px-modal']//button[text()='Save']")).click();
		}; 
		//Define portfolio Management
		this.portfolioDefineportTab = function(){
		//element(by.xpath("//div[@id='myUserDiv']/div//px-tab/div[@class='tab-title style-scope px-tab tab-title--selected']")).click();
		element(by.xpath("//section[@role='region']//px-tab[@class='iron-selected']/div")).click();
		}; 
		this.portfolioDefinePortfolioName = function(Value){
		element(by.model("definePortfolio.portfolioSearchName")).sendKeys(Value);
		};
		this.portfolioSearchButton = function(){
		element(by.css("input[value='Search Portfolio']")).click();
		};
		this.portfolioAddDefinePortfolioButton = function(){
		element(by.css("#add")).click();
		};
		this.portfolioAddDefineRadioButton = function(){
		element(by.xpath("//*[@id='scrollBodyTableContainer']/div[3]/px-data-table-cell[1]/aha-html-echo/div/input")).click();
		};
		this.portfolioAddPortfolioName = function(Value){
		element(by.css("input[id^='portfolioName']")).sendKeys(Value);
		};
		this.portfolioAddPortfolioDescription = function(Value){
		element(by.css("input[id^='portfolioDesc']")).sendKeys(Value);
		};
		this.portfolioAddPortfolioStatus = function(Value){
		new SelectWrapper(by.css("select[id^='portfolioStatus']")).selectByValue(Value);
		};
		this.portfolioAddPortfolioRegion = function(){
		element(by.css("input[id^='regionChkBox']")).click();
		};
		this.portfolioAddPortfolioQuarter = function(){
		element(by.css("input[id^='qtrChkBox']")).click();
		};
		this.portfolioAddPortfolioSaveButton = function(){
		element(by.css("#tabPage1 > div:nth-child(3) > span:nth-child(3)")).click();
		};
  }; 
      
  module.exports= new Portfolio_Mang();
  
  
  