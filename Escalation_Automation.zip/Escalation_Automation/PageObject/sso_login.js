/**
 * login page
 */

require('../PageObject/sso_login.js');

var sso_login = function() {
	
	this.go=function(value){
	//browser.get("https://dev-shared.energy.ge.com/cs-escalation/");
	browser.get("https://dev-bld-escalation.pw.ge.com/cs-escalation/");
	};
    this.username=function(value){
		element(By.xpath("//input[@id='username']")).sendKeys(value);
		};
				
		this.password=function(pwd){
			browser.driver.findElement(By.xpath("//input[@id='password']")).sendKeys(pwd);
			};
			
			this.signin_button=function(){
			browser.driver.findElement(By.xpath("//input[@id='submitFrm']")).click();			
			};
  };
  
  module.exports= new sso_login();