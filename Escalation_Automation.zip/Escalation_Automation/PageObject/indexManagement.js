/**
 * login page
 */

require('../PageObject/indexManagement.js');
var SelectWrapper = require('./select-wrapper.js');

var Index_Mang = function() {
	
    	this.indexManagments = function(){
		element(By.css("#navitemlist > li:nth-child(3) > a > span")).click();
		};
		this.indexStatusSelection = function(value){
		new SelectWrapper(by.model("series.statuss")).selectByValue(value);
		};
		this.indexYearSelection = function(value){
		new SelectWrapper(by.model("series.year")).selectByValue(value);
		};
		this.indexSeriesSelection = function(value){
		new SelectWrapper(by.model("series.seriesName")).selectByValue(value);
		};
		this.indexPeriodSelection = function(value){
		new SelectWrapper(by.model("series.period")).selectByValue(value);
		};
		this.indexSearchButton = function(){
		element(By.css("input[value='Search Index']")).click();
		};
		this.indexSaveButton = function(){
		element(By.css("#save")).click();
		};
        this.indexMenuActionsButton = function(){
		element(By.css("span[class='menuActions']")).click();;
		};
		
        this.indexAddindexButton = function(){
		element(By.css("$$('li[ng-click='AddIndex()']')")).click();
		};
        this.indexAddindexSeriesDropdown = function(value){
		new SelectWrapper(By.css("select[id='drpSeries1']")).selectByText(value);
		};
		this.indexAddindexYearDropdown = function(value){
		new SelectWrapper(By.css("select[id='drpYear1']")).selectByText(value);
		};
		this.indexAddindexPeriodDropdown = function(value){
		new SelectWrapper(By.css("select[id='drpPeriod1']")).selectByText(value);
		};
		this.indexAddindexValuefield = function(value){
		element(By.css("input[id='txtValue1']")).sendKeys(value);
		};
		this.indexAddindexStatusDropdown = function(value){
		element(By.css("select[id='drpStatus1']")).selectByText(value);
		};
		this.AddedIndexAlertMessage = function(){
		element(by.binding("alertMessage")).getText() 
		}; 
		 //Delete Index -Index Management
		this.indexDeleteButton = function(){
		element(By.css("#deleteTooltip")).click();
		};
		this.indexDeleteYesButton = function(){
		element(By.css("#Yes")).click();
		};
		// Downloading Index value Template Excel sheet
		this.indexDownloadTemplateButton = function(){
		element(By.css("#indexContainer > form:nth-child(3) > div > div:nth-child(2) > span:nth-child(4) > span > ul > li:nth-child(2)")).click();
		};
		// Downloading Index value data Excel sheet
		this.indexDownloadIndexDataButton = function(){
		element(By.css("#indexContainer > form:nth-child(3) > div > div:nth-child(2) > span:nth-child(4) > span > ul > li:nth-child(3)")).click();
		};
		//Create series - Index management
  }; 
      
  module.exports= new Index_Mang();
  
  
  