/**
 * Escalation app
 */
'use strict';
var util = require('./utilities');

var SelectWrapper = require('./select-wrapper.js');

describe("Automation of Escalation Application - User Management",function(){

 var sso_login = require('../PageObject/sso_login.js');
 var Escalation_home = require('../PageObject/Escalation_home.js');
 //var User_Management = require('../PageObject/User_Management.js');
 var scenarioMng = require('../PageObject/scenarioManagement.js');
  
    beforeEach(function() {			
	browser.ignoreSynchronization = true;
	browser.driver.manage().window().maximize();	
	}); 
   
   it("should be able to Login with sso in the system",function(){
       //browser.get("https://dev-bld-escalation.pw.ge.com/cs-escalation/");
	   sso_login.go();
	   browser.driver.sleep(5000);
       sso_login.username('501302518');
	   sso_login.password('GE2014@work');
	   sso_login.signin_button();
	   //browser.driver.sleep(10000);
	   expect(browser.getCurrentUrl()).not.toEqual('https://dev-bld-escalation.pw.ge.com/cs-escalation/');	   
   }, 120000);
   
    afterEach(function() {
	browser.ignoreSynchronization = false;
	}); 
	
	it("should be able to reach to Escalation Dashboard home screen",function(){
       browser.driver.sleep(25000);       
	   Escalation_home.role('0');
	   Escalation_home.enter_button();
	   browser.driver.sleep(10000);	
       expect(browser.getCurrentUrl()).toBe('https://dev-shared.energy.ge.com/home');
	   //expect(Escalation_home.role.headerText.getText()).toEqual('ROLE SELECTION');
   }, 120000) ;
   
   // Scenario Management section
   it("should be able to navigates into Scenario Management",function(){   	
	   scenarioMng.scenarioManagments();
	   browser.driver.sleep(3000);	
	   	scenarioMng.defineScenarioTab();		
		browser.driver.sleep(3000);
       expect(element(By.css("input[value='Search Scenario']")).isPresent()).toBe(true);	   
   }, 120000);
   
    it("should be able to Search existing define scenarios - Scenario Management",function(){   	
	   scenarioMng.defineScenarioTagDropdown('1');
	   browser.driver.sleep(2000);	
	   	scenarioMng.defineScenarioSearchButton();		
		browser.driver.sleep(3000);
       expect(element(By.css("input[value='Search Scenario - Scenario Management']")).isPresent()).toBe(true);	   
   }, 120000);
   
   it("should be able to create new define scenarios - Scenario Management",function(){   	
	   scenarioMng.defineScenarioAddButton();
	   browser.driver.sleep(2000);	
	   scenarioMng.defineScenarioAddTagName('2');
	   scenarioMng.defineScenarioAddScenarioName('QA Testing');
	   scenarioMng.defineScenarioAddScenarioDesc('QA Testing');
	   browser.driver.sleep(3000);
		scenarioMng.defineScenarioSaveButton();
		browser.driver.sleep(5000);
       expect(element(by.binding("alertMessage")).getText()).toBe("Save has been completed succesfully");		   
   }, 120000);
   
});