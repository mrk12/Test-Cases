/**
 * Escalation app
 */

var util = require('util')

//var SelectWrapper = require('./select-wrapper.js');

describe("Automation of Escalation Application - User Management",function(){

 var sso_login = require('../PageObject/sso_login.js');
 var Escalation_home = require('../PageObject/Escalation_home.js');
 var User_Management = require('../PageObject/User_Management.js');
  
    beforeEach(function() {
	//browser.manage().timeouts().implicitlyWait(10000);		
	browser.ignoreSynchronization = true;
	browser.driver.manage().window().maximize();
	
	}); 
   
   it("should be able to enter a valid sso in the system",function(){
       sso_login.go();	   
       sso_login.username('501302518');
	   sso_login.password('GE2014@work');
	   sso_login.signin_button();	   
	   expect(browser.getCurrentUrl()).toBe('https://dev-shared.energy.ge.com/userLogin');	
  
   }, 120000) ;
   
    afterEach(function() {
	browser.ignoreSynchronization = false;
	}); 
	
	it("should be able to reach to Escalation Dashboard home screen",function(){
       browser.driver.sleep(35000);		
       //Escalation_home.sso_id('501302518');
	   //Escalation_home.submit_button();
	   //browser.driver.sleep(5000);	
	   Escalation_home.role('0');
	   Escalation_home.enter_button();
	   browser.driver.sleep(10000);	
       expect(browser.getCurrentUrl()).toBe('https://dev-shared.energy.ge.com/home');
	   
   }, 120000) ;
   
    it("Should be able to reach to Use Management tab and Add a new user",function(){
       //browser.driver.sleep(5000);		
       User_Management.user_managm();
	   browser.driver.sleep(10000);	  
	  User_Management.Adduser_Ssoid('105015069');
	   User_Management.lookupSSO_button();
	   browser.driver.sleep(3000);
       User_Management.Select_Role();
	   browser.driver.sleep(3000);
	   User_Management.Adduser_Button();
	   browser.driver.sleep(3000);
	var AddUser = element(by.binding("alertMessage")).getText();            
		expect(AddUser).toBe("User Added Successfully");
		
       }, 120000);
				
		it("should be able to edit the role of the added user",function(){
		browser.driver.sleep(3000);
		User_Management.Search_User('Ana herrera');
	   browser.driver.sleep(3000);
		User_Management.Edit_User();
		browser.driver.sleep(3000);
	   User_Management.SelectUser_Role();
	   User_Management.EditUser_SaveButton();
	   browser.driver.sleep(3000);
		var EditUser = element(by.binding("alertMessage")).getText();
        expect(EditUser).toBe("User roles modified successfully"); 
		
	  }, 120000);
	  
	it("should be able to delete the recently added user",function(){		
	   browser.driver.sleep(3000);
		User_Management.Delete_User();
		browser.driver.sleep(3000);
	   User_Management.Yes_Button();
	   browser.driver.sleep(3000);
		var deleteUser = element(by.binding("alertMessage")).getText();            
		expect(deleteUser).toEqual("User deleted successfully");	
        
	  }, 120000); 
	  
    //Model Mapping - User Management
	
	it("Should be able to reach to Use Management-Model Mapping tab and Add a new user",function(){	
    User_Management.modelMappingTab();
	browser.driver.sleep(10000);
	User_Management.modelidSearchInput('1112');
	User_Management.modelidSearchButton();
	browser.driver.sleep(10000);
	User_Management.modelMappingAddButton();
	browser.driver.sleep(3000);
	User_Management.modelidAddInput('1112');
	browser.driver.sleep(3000);
	User_Management.selectUsername('2643');
	browser.driver.sleep(3000);
	User_Management.selectUserRole('2');
	browser.driver.sleep(3000);
	User_Management.saveButton();
	browser.driver.sleep(3000);
	var ModelMappingAddUser = element(by.binding("alertMessage")).getText();            
	expect(ModelMappingAddUser).toBe("Model Id 1112 has been mapped to user Mahendran Gautham (502278427) with role Escalation Manager successfully");
	
	}, 120000); 
	
	it("should be able to Navigates into Model Mapping",function(){
	User_Management.user_managm();
	browser.driver.sleep(3000);
	User_Management.modelMappingTab();
	expect(element(By.xpath("//div[@id='tabtitle'][text()='Model Mapping']")).isPresent()).toBe(true);
	}, 120000);	
	
	it("should be able to search added users - Model Mapping",function(){
	User_Management.modelidSearchInput('1112');
	User_Management.modelidSearchButton();
	browser.driver.sleep(3000);
	expect(element(by.id("save")).isPresent()).toBe(true);
	}, 120000);	
	
	it("should be able to filter added user - Model Mapping",function(){	
	User_Management.modelMappingFilter("gautham");	          
	expect(element(by.id("save")).isPresent()).toBe(true);
	}, 120000);
	
	it("should be able to Edit the Role and Name of the added user - Model Mapping",function(){		
	User_Management.modelMappingEditUser();
	browser.driver.sleep(2000);
	User_Management.selectRolename('3');
	User_Management.selectEditUsername('Alper Akyildiz (105044647)');
	}, 120000);
	
	it("should be able to Edit the added user - Model Mapping",function(){
	User_Management.editUserSaveButton();
	browser.driver.sleep(2000);
	expect(element(by.binding("alertMessage")).getText()).toBe("Model Mapping has been updated successfully");
	}, 120000);	
		 
    it("should be able to search the user to Delete - Model Mapping",function(){	
	User_Management.modelMappingFilterClear();	
	User_Management.modelMappingFilterUser('Alper Akyildiz');
	expect(element(by.id("save")).isPresent()).toBe(true);
	}, 120000);
	
	it("should be able to Delete the searched user - Model Mapping",function(){
	User_Management.deleteUserButton();	
	User_Management.Yes_Button();
    browser.driver.sleep(3000);	          
	expect(element(by.binding("alertMessage")).getText()).toBe("Model Mapping has been deleted successfully");	
     }, 120000); 
});