/**
 * Escalation app
 */

'use strict';
var util = require('./utilities');

var SelectWrapper = require('./select-wrapper.js');

describe("Automation of Escalation Application - Portfolio Management",function(){

 var sso_login = require('../PageObject/sso_login.js');
 var Escalation_home = require('../PageObject/Escalation_home.js'); 
 var portfolioManagement = require('../PageObject/portfolioManagement.js');
  
    beforeEach(function() {			
	browser.ignoreSynchronization = true;
	browser.driver.manage().window().maximize();	
	}); 
   
   it("should be able to Login with sso in the system",function(){
       //browser.get("https://dev-bld-escalation.pw.ge.com/cs-escalation/");
	   sso_login.go();
	   browser.driver.sleep(5000);
       sso_login.username('501302518');
	   sso_login.password('GE2014@work');
	   sso_login.signin_button();
	   //browser.driver.sleep(10000);
	   expect(browser.getCurrentUrl()).not.toEqual('https://dev-bld-escalation.pw.ge.com/userRoles');	   
   }, 120000);
   
    afterEach(function() {
	browser.ignoreSynchronization = false;
	}); 
	
	it("should be able to reach to Escalation Dashboard home screen",function(){
       browser.driver.sleep(20000);		
       //Escalation_home.sso_id('501302518');
	   //Escalation_home.submit_button();
	   //browser.driver.sleep(5000);	
	   Escalation_home.role('0');
	   Escalation_home.enter_button();
	   browser.driver.sleep(10000);	
       expect(browser.getCurrentUrl()).toBe('https://dev-bld-escalation.pw.ge.com/home');	   
   }, 120000) ;
   
   // Portfolio Management section
   
   it("should be able to navigates into Portfolio Management",function(){
       	   
	   portfolioManagement.portfolioManagmentTab();
	   browser.driver.sleep(5000);
	   expect(element(by.css("input[placeholder='Model ID']")).isPresent()).toEqual(true);
	   }, 120000);
	   
	   /* it("should be able to search with modelid - Portfolio Management",function(){		   
	    portfolioManagement.portfolioModelid('1112');	   
	   browser.driver.sleep(3000);
	   portfolioManagement.portfolioSearchButton();
	   expect(element(By.css("input[type='submit']")).isPresent()).toBe(true);
   }, 120000);
   
     it("should be able to click on Add portfolio buttonn - Portfolio Management",function(){     	   
	   browser.driver.sleep(3000);
	   portfolioManagement.portfolioAddButton();
     browser.driver.sleep(5000);	   
       expect(element(By.css("input[id^='modelIdValue']")).isPresent()).toBe(true);	   
   }, 120000);
   
     it("should be able to enter modelid in new portfolio record - Portfolio Management",function(){	   
	   portfolioManagement.portfolioAddModelid('1112');
	   portfolioManagement.portfolioAddContractNumber('9854634');
	   expect(element(by.css("input[id^='custNameValue']")).isPresent()).toBe(true);	   
	   }, 120000);
	   
     it("should be able to enter Customer Name in new portfolio record - Portfolio Management",function(){	   
	   portfolioManagement.portfolioAddCustomerName('QA Testing');	   
	   expect(element(by.css("input[id^='custNameValue']")).isPresent()).toBe(true);	   
	   }, 120000);
	   
     it("should be able to enter Start & End date in new portfolio record - Portfolio Management",function(){	   
	   portfolioManagement.portfolioAddStartDate('01/01/2015');
	   portfolioManagement.portfolioAddEndDate('01/01/2017');
	   expect(element(by.css("input[id^='startDateValue']")).isPresent()).toBe(true);	   
	   }, 120000);
	   
	   it("should be able to enter region in new portfolio record - Portfolio Management",function(){
		browser.driver.sleep(2000);   
	   portfolioManagement.portfolioAddMrQuarter('3Q');
	   browser.driver.sleep(2000);
	   portfolioManagement.portfolioAddRegion('16');
	   browser.driver.sleep(2000);
	   portfolioManagement.portfolioAddLastLockedMR('CR2013 1Q');
	   browser.driver.sleep(2000);
	   portfolioManagement.portfolioAddOptions('In-Scope');
	   expect(new SelectWrapper(by.css("select[id^='drpOptions']")).isPresent()).toBe(true);	   
	   }, 120000);
	   
	   it("should be able to save newly added portfolio record - Portfolio Management",function(){
       browser.driver.sleep(3000);		   
	   portfolioManagement.portfolioSaveButton();
	   browser.driver.sleep(5000);	   	
      expect(element(by.binding("alertMessage")).getText()).toBe("Model data has been added for ModelId 1112 and ContractNumber test successfully");	   
	   }, 120000);
	   
      // Edit portfolio record - Portfolio Management
       it("should be able to Edit newly added portfolio model record - Portfolio Management",function(){
       browser.driver.sleep(3000);		   
	   portfolioManagement.portfolioEditModel();
	   expect(element(by.css("#editModelTooltip")).isPresent()).toBe(true);	   
	   }, 120000);
	   
	   it("should be able to Edit region - Portfolio Management",function(){	   
	   portfolioManagement.portfolioEditRegionModel('4');
	   browser.driver.sleep(2000);
	   portfolioManagement.portfolioEditComments('QA Testing');
	   browser.driver.sleep(3000);
	   portfolioManagement.portfolioEditSaveButton();
	   browser.driver.sleep(5000);
	   expect(element(by.binding("alertMessage")).getText()).toBe("Model has been edited successfully");   
	   }, 120000); */
	   
	   //Define portfolio management
	  it("should be able to Navigates into Define portfolio tab - Portfolio Management",function(){
       browser.driver.sleep(3000);		   
	   portfolioManagement.portfolioDefineportTab();
	   browser.driver.sleep(3000);
	  expect(element(by.xpath("//section[@role='region']//px-tab[@class='iron-selected']/div")).isPresent()).toBe(true);	   
	   }, 120000);
	   
	   it("should be able to search the Define portfolio - Portfolio Management",function(){
       browser.driver.sleep(3000);		   
	   portfolioManagement.portfolioDefinePortfolioName('port');
	   portfolioManagement.portfolioSearchButton();
	   browser.driver.sleep(3000);
	  expect(element(by.css("input[value='Search Portfolio']")).isPresent()).toBe(true);	   
	   }, 120000);
	   
	   it("should be able to create new row - Portfolio Management",function(){
       browser.driver.sleep(3000);		   
	   portfolioManagement.portfolioAddDefinePortfolioButton();	   
	   browser.driver.sleep(3000);
	  expect(element(by.css("input[id^='portfolioName']")).isPresent()).toBe(true);	   
	   }, 120000);
	   
	   it("should be able to enter Name and description to create new portfolio - Portfolio Management",function(){       	   
	   portfolioManagement.portfolioAddDefineRadioButton();
	   portfolioManagement.portfolioAddPortfolioName('QA Testing');
	   portfolioManagement.portfolioAddPortfolioDescription('QA Testing');
	   portfolioManagement.portfolioAddPortfolioStatus('Public');
	   browser.driver.sleep(3000);
	  expect(element(by.css("input[id^='portfolioName']")).isPresent()).toBe(true);	   
	   }, 120000);
	   
	   it("should be able to select Region and Quarter to create new portfolio - Portfolio Management",function(){       	   
	   portfolioManagement.portfolioAddPortfolioRegion();
	   portfolioManagement.portfolioAddPortfolioQuarter();	  
	   browser.driver.sleep(3000);
	   portfolioManagement.portfolioAddPortfolioSaveButton();
	   browser.driver.sleep(5000);
	   expect(element(by.binding("alertMessage")).getText()).toBe("SUCCESS");	   
	   }, 120000);
	   
});