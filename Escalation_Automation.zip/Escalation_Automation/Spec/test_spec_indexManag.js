/**
 * Escalation app
 */
'use strict';
var util = require('./utilities');

var SelectWrapper = require('./select-wrapper.js');

describe("Automation of Escalation Application - User Management",function(){

 var sso_login = require('../PageObject/sso_login.js');
 var Escalation_home = require('../PageObject/Escalation_home.js');
 //var User_Management = require('../PageObject/User_Management.js');
 var indexManagement = require('../PageObject/indexManagement.js');
  
    beforeEach(function() {			
	browser.ignoreSynchronization = true;
	browser.driver.manage().window().maximize();	
	}); 
   
   it("should be able to Login with sso in the system",function(){
       //browser.get("https://dev-bld-escalation.pw.ge.com/cs-escalation/");
	   sso_login.go();
	   browser.driver.sleep(5000);
       sso_login.username('501302518');
	   sso_login.password('GE2014@work');
	   sso_login.signin_button();
	   //browser.driver.sleep(10000);
	   expect(browser.getCurrentUrl()).not.toEqual('https://dev-bld-escalation.pw.ge.com/cs-escalation/');	   
   }, 120000);
   
    afterEach(function() {
	browser.ignoreSynchronization = false;
	}); 
	
	it("should be able to reach to Escalation Dashboard home screen",function(){
       browser.driver.sleep(25000);       
	   Escalation_home.role('0');
	   Escalation_home.enter_button();
	   browser.driver.sleep(10000);	
       expect(browser.getCurrentUrl()).toBe('https://dev-shared.energy.ge.com/home');
	   //expect(Escalation_home.role.headerText.getText()).toEqual('ROLE SELECTION');
   }, 120000) ;
   
   // Index management section
   it("should be able to navigates into Index Management",function(){   	
	   indexManagement.indexManagments();
	   browser.driver.sleep(8000);	
	   	indexManagement.indexYearSelection('23');		
		indexManagement.indexSearchButton();
		browser.driver.sleep(15000);
       expect(element(By.css("input[value='Search Index']")).isPresent()).toBe(true);	   
   }, 120000);
   
   it("should be able to click on Add Index buttonn - Index Management",function(){     	   
	   indexManagement.indexMenuActionsButton();
	   browser.driver.sleep(3000);
	   indexManagement.indexAddindexButton();
      browser.driver.sleep(15000);	   
       expect(element(By.css("input[id='txtValue1']")).isPresent()).toBe(true);	   
   }, 120000);
   
   it("should be able to create new index record - Index Management",function(){	   
	   indexManagement.indexAddindexSeriesDropdown('ICL Industry');
	   indexManagement.indexAddindexYearDropdown('2013');
       indexManagement.indexAddindexPeriodDropdown('Sep');
	   indexManagement.indexAddindexValuefield('100');
	   indexManagement.indexAddindexValuefield('Final');
	   browser.driver.sleep(3000);
	   indexManagement.indexSaveButton();
	   browser.driver.sleep(8000);
       expect(element(by.binding("alertMessage")).getText()).toBe('Index Data inserted for ICL Industry Year : 2013 Period : Sep Status :Final');	   
   }, 120000);
   
    it("should be able to search the added Index - Index Management",function(){	   
	   //browser.driver.sleep(10000);
	    indexManagement.indexSeriesSelection('34');
	   	indexManagement.indexYearSelection('23');
		indexManagement.indexPeriodSelection('8');
		indexManagement.indexStatusSelection('1');
		indexManagement.indexSearchButton();		
       expect(element(By.css("input[value='Search Index']")).isPresent()).toBe(false);	   
   }, 120000);
   
    it("should be able to Delete the added Index - Index Management",function(){	   
	   //browser.driver.sleep(10000);
	    indexManagement.indexDeleteButton();	   			
       expect(element(By.css("#myModal > section > p > b")).getText()).toBe('Do you want to delete this Index Value?');	   
   }, 120000);
   
   it("should be able to view Index value Delete conformation Message - Index Management",function(){	    
	   indexManagement.indexDeleteYesButton();
	   expect(element(by.binding("alertMessage")).getText()).toBe('Index value deleted successfully');
   }, 120000);
   
    it("should be able to Download template Excel sheet - Index Management",function(){	    
	   indexManagement.indexMenuActionsButton();
	   indexManagement.indexDownloadTemplateButton();
	   expect(element(By.css("#save")).isPresent()).toBe(true);
   }, 120000);
   
   it("should be able to Download template Excel sheet - Index Management",function(){	   
	   indexManagement.indexDownloadIndexDataButton();
	   expect(element(By.css("#save")).isPresent()).toBe(true);
   }, 120000);
   
});