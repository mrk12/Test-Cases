/**
 * New node file
 */
//the below code is working fine but not generating the html report

var HtmlScreenshotReporter = require('protractor-jasmine2-html-reporter');
var del = require('delete');

var today = new Date(),
    timeStamp = today.getMonth() + 1 + '-' + today.getDate() + '-' + today.getFullYear() + '-' + today.getHours() + 'h-' + today.getMinutes() + 'm';

var reporter = new HtmlScreenshotReporter({
    savePath: './Test Report/Result'+timeStamp+'/',
    screenshotsFolder: 'images'
});

function send_mail() {
    console.log("Sending Mail with reports for the test execution.");
    var sys = require('util')
    var exec = require('child_process').exec;

    function puts(error, stdout, stderr) {
        sys.puts(stdout)
    }
    exec("node mail.js", puts);
}

function deleteFile(value){
	del([value], function(err) {
		  if (err) throw err;
		  console.log('done!');
		});
}

exports.config = {
    directconnect: true,

    //seleniumAddress: 'http://localhost:4444/wd/hub',,

    capabilities: {
        'browserName': 'chrome'
    },

    framework: 'jasmine2',
    specs: ['../Tests/test-spec.js'],

    onPrepare: function() {
		
		var AllureReporter = require('jasmine-allure-reporter');
		var del = require('delete');
		var detectBrowser = require('detect-browser');

		deleteFile('./allure-results/*.png');
		deleteFile('./allure-results/*.xml');
		deleteFile('./node_modules/jasmine-allure-reporter/allure-results/*.png');
		deleteFile('./node_modules/jasmine-allure-reporter/allure-results/*.xml');

		jasmine.getEnv().addReporter(new AllureReporter({
			allureReport:{
				resultsDir: 'allure-results'
			}
		}));

		jasmine.getEnv().afterEach(function(done){
		  browser.takeScreenshot().then(function (png) {
			allure.createAttachment('Screenshot', function () {
			  return new Buffer(png, 'base64')
			},'image/png')();
			done();
		  })
		});
    }, 

	onComplete: function() {

		var fsextra = require('fs-extra')
		var fs = require('fs');
		var zipFolder = require('zip-folder');
		var exec = require('child_process').exec;
		
		//Copy files
		fsextra.copy('./allure-results', './node_modules/jasmine-allure-reporter/allure-results', function (err) {
		  if (err) return console.error(err)
		  console.log("success!")
		});
		 
		try {
		  fsextra.copySync('./allure-results', './node_modules/jasmine-allure-reporter/allure-results')
		  console.log("success!")
		} catch (err) {
		  console.error(err)
		}
		
		//Rename 'index.html' file
		/*fs.rename('./node_modules/jasmine-allure-reporter/target/site/allure-maven-plugin/index.html', './node_modules/jasmine-allure-reporter/target/site/allure-maven-plugin/index_'+timeStamp+'.html', function(err) {
			if ( err ) console.log('ERROR: ' + err);
		});*/ 
		
		//Execute shell command in npm command prompt	
		var cmd = "D:" + 
		  " && cd /Protractor Stuff/protractor_project/node_modules/jasmine-allure-reporter" +
          " && mvn site -Dallure.results_pattern=allure-results"; 

			var exec = require("child_process").execSync;
			exec(cmd, function(err, stdout, stderr){
			  if (err) console.log(err);
			  console.log(stdout);
			}); 

			////create 'TestResults' folder
			//fs.mkdirSync('./Test Report/TestResults_'+timeStamp);

		//Zip result folder
		/*zipFolder('./node_modules/jasmine-allure-reporter/target/site/allure-maven-plugin', './node_modules/jasmine-allure-reporter/target/site/allure-maven-plugin.zip', function(err) {
			if(err) {
				console.log('oh no!', err);
			} else {
				console.log('EXCELLENT');
			}
		});

		var zipdir = require('zip-dir');
		zipdir('./node_modules/jasmine-allure-reporter/target/site/allure-maven-plugin', function (err, buffer) {
			// `buffer` is the buffer of the zipped file 
		});*/
	},

	onCleanUp: function(exitCode) {

		/*var fsextra = require('fs-extra')

		//copy zip file to Test Report folder
		try {
		  fsextra.copySync('./node_modules/jasmine-allure-reporter/target/site/allure-maven-plugin.zip', './Test Report/allure-maven-plugin.zip')
		  console.log("success!")
		} catch (err) {
		  console.error(err)
		}

		var AdmZip = require('adm-zip');
		var zip = new AdmZip("./Test Report/allure-maven-plugin.zip"),
		zipEntries = zip.getEntries();
    zip.extractAllTo("./Test Report/", true);*/
	},
    // Options to be passed to Jasmine-node.
    jasmineNodeOpts: {
        showColors: true,
        defaultTimeoutInterval: 100000
    },
};