/**
 * Created by jt on 7/17/2016.
 */

var cellFromXLS = function () {
    this.excel = function (cellId) {
        'use strict';
        //Define sheetNumber
        var sheetNumber = 0;
        //Define file Path name
        var fileNamePath = path.join(dirPath, 'C:/Users/jt/Desktop/data1.xlsx');
        //NodeJs read file
        var XLS;
        if (typeof require !== 'undefined') {
            XLS = require('xlsjs');
        }
        //Working with workbook
        var workbook = XLS.readFile(fileNamePath);
        var sheetNamelist = workbook.SheetNames;
        var value = workbook.Sheets[sheetNamelist[sheetNumber]][cellId].v;
        return value;
    };
};

module.exports = new cellFromXLS();


