/**
 * New node file
 */
//require('./confirm_page.js');
var OR = require('D:/Protractor Stuff/protractor_project/TestData/animal_page.json');
var animal_page = function () {

  this.selectAnimal = function (index) {
    element(eval(OR.locators.homepage.animalbutton)).$('[value="' + index + '"]').click();
  };

  this.clickContinue = function () {
    element(eval(OR.locators.homepage.clickContinue)).click();
    return require('./confirm_page.js');
  };
};
module.exports = new animal_page();