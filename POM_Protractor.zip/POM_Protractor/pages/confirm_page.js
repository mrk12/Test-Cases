/**
 * New node file
 */
var OR = require('D:/Protractor Stuff/protractor_project/TestData/animal_page.json');
var confirm_page = function () {

  this.getTitle = function () {
    return element(eval(OR.locators.homepage.confirm)).getText();
  };
};

module.exports = new confirm_page();