/**
 * New node file
 */

//require('./animal-page.js');
var OR = require('D:/Protractor Stuff/protractor_project/TestData/animal_page.json');
var home_page = function(){
  this.enterFieldValue = function (value) {
    element(eval(OR.locators.homepage.personName)).sendKeys(value);
    };

  this.getDynamicText = function () {
    return element(eval(OR.locators.homepage.ngclickbutton)).getText();
  };

  this.clickContinue = function () {
    element(eval(OR.locators.homepage.clickContinue)).click();
    return require('./animal-page.js');
  };
};
module.exports = new home_page();

