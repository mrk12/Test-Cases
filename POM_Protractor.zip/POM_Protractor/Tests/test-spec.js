/**
 * New node file
 */

var util = require('util')

var OR = require('D:/Protractor Stuff/protractor_project/TestData/animal_page.json');
describe('Verify the Animal adoption application flow', function() {

    var home_page = require('../pages/home-page.js');
    var animal_page = require('../pages/animal-page.js');
    var confirm_page = require('../pages/confirm_page.js');
    //var excel_page = require('../excelRead.js');

    it('Navigate to adopt an animal application', function() {
        browser.get(OR.testsiteurl);
        expect(browser.getCurrentUrl()).toBe('http://www.thetestroom.com/jswebapp/index.html')
    });

    it('Enter your name to adopt an animal and select the animal catagory',function () {
      home_page.enterFieldValue(OR.locators.testdata.fname);
      var getHomePageText = home_page.getDynamicText();
      expect(getHomePageText).toBe('Raju');
      var animal_page = home_page.clickContinue();
      animal_page.selectAnimal(2);
    });

    it('Verify if the animal adoption is successfully completed', function () {
      var confirm_page = animal_page.clickContinue();
      expect(confirm_page.getTitle()).toBe('Thank you');
    });
});
